EESchema Schematic File Version 2
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:power
LIBS:eSim_Plot
LIBS:transistors
LIBS:conn
LIBS:eSim_User
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_Nghdl
LIBS:eSim_Ngveri
LIBS:eSim_SKY130
LIBS:eSim_SKY130_Subckts
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L power_gating_ic_ip X1
U 1 1 69C6D68B
P 4950 3300
F 0 "X1" H 4950 3300 60  0000 C CNN
F 1 "power_gating_ic_ip" H 5000 3250 60  0000 C CNN
F 2 "" H 4950 3300 60  0001 C CNN
F 3 "" H 4950 3300 60  0001 C CNN
	1    4950 3300
	1    0    0    -1  
$EndComp
$Comp
L pulse v1
U 1 1 69C6D711
P 1500 3400
F 0 "v1" H 1300 3500 60  0000 C CNN
F 1 "pulse" H 1300 3350 60  0000 C CNN
F 2 "R1" H 1200 3400 60  0000 C CNN
F 3 "" H 1500 3400 60  0000 C CNN
	1    1500 3400
	1    0    0    -1  
$EndComp
$Comp
L pulse v2
U 1 1 69C6D748
P 1700 3500
F 0 "v2" H 1500 3600 60  0000 C CNN
F 1 "pulse" H 1500 3450 60  0000 C CNN
F 2 "R1" H 1400 3500 60  0000 C CNN
F 3 "" H 1700 3500 60  0000 C CNN
	1    1700 3500
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR01
U 1 1 69C6DEF3
P 1900 3900
F 0 "#PWR01" H 1900 3650 50  0001 C CNN
F 1 "GND" H 1900 3750 50  0000 C CNN
F 2 "" H 1900 3900 50  0001 C CNN
F 3 "" H 1900 3900 50  0001 C CNN
	1    1900 3900
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR02
U 1 1 69C6DF1F
P 1700 3950
F 0 "#PWR02" H 1700 3700 50  0001 C CNN
F 1 "GND" H 1700 3800 50  0000 C CNN
F 2 "" H 1700 3950 50  0001 C CNN
F 3 "" H 1700 3950 50  0001 C CNN
	1    1700 3950
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR03
U 1 1 69C6DF4B
P 1500 3850
F 0 "#PWR03" H 1500 3600 50  0001 C CNN
F 1 "GND" H 1500 3700 50  0000 C CNN
F 2 "" H 1500 3850 50  0001 C CNN
F 3 "" H 1500 3850 50  0001 C CNN
	1    1500 3850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U10
U 1 1 69C6DFEF
P 3800 2850
F 0 "U10" H 3800 3350 60  0000 C CNN
F 1 "plot_v1" H 4000 3200 60  0000 C CNN
F 2 "" H 3800 2850 60  0000 C CNN
F 3 "" H 3800 2850 60  0000 C CNN
	1    3800 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U9
U 1 1 69C6E0B9
P 3550 2850
F 0 "U9" H 3550 3350 60  0000 C CNN
F 1 "plot_v1" H 3750 3200 60  0000 C CNN
F 2 "" H 3550 2850 60  0000 C CNN
F 3 "" H 3550 2850 60  0000 C CNN
	1    3550 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U8
U 1 1 69C6E13F
P 3000 2850
F 0 "U8" H 3000 3350 60  0000 C CNN
F 1 "plot_v1" H 3200 3200 60  0000 C CNN
F 2 "" H 3000 2850 60  0000 C CNN
F 3 "" H 3000 2850 60  0000 C CNN
	1    3000 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U7
U 1 1 69C6E17E
P 2750 2850
F 0 "U7" H 2750 3350 60  0000 C CNN
F 1 "plot_v1" H 2950 3200 60  0000 C CNN
F 2 "" H 2750 2850 60  0000 C CNN
F 3 "" H 2750 2850 60  0000 C CNN
	1    2750 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U6
U 1 1 69C6E1C3
P 2500 2850
F 0 "U6" H 2500 3350 60  0000 C CNN
F 1 "plot_v1" H 2700 3200 60  0000 C CNN
F 2 "" H 2500 2850 60  0000 C CNN
F 3 "" H 2500 2850 60  0000 C CNN
	1    2500 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U5
U 1 1 69C6E208
P 2250 2850
F 0 "U5" H 2250 3350 60  0000 C CNN
F 1 "plot_v1" H 2450 3200 60  0000 C CNN
F 2 "" H 2250 2850 60  0000 C CNN
F 3 "" H 2250 2850 60  0000 C CNN
	1    2250 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U4
U 1 1 69C6E24D
P 2000 2850
F 0 "U4" H 2000 3350 60  0000 C CNN
F 1 "plot_v1" H 2200 3200 60  0000 C CNN
F 2 "" H 2000 2850 60  0000 C CNN
F 3 "" H 2000 2850 60  0000 C CNN
	1    2000 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U3
U 1 1 69C6E294
P 1800 2850
F 0 "U3" H 1800 3350 60  0000 C CNN
F 1 "plot_v1" H 2000 3200 60  0000 C CNN
F 2 "" H 1800 2850 60  0000 C CNN
F 3 "" H 1800 2850 60  0000 C CNN
	1    1800 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U11
U 1 1 69C6E32E
P 4000 2850
F 0 "U11" H 4000 3350 60  0000 C CNN
F 1 "plot_v1" H 4200 3200 60  0000 C CNN
F 2 "" H 4000 2850 60  0000 C CNN
F 3 "" H 4000 2850 60  0000 C CNN
	1    4000 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U1
U 1 1 69C6E725
P 1450 2850
F 0 "U1" H 1450 3350 60  0000 C CNN
F 1 "plot_v1" H 1650 3200 60  0000 C CNN
F 2 "" H 1450 2850 60  0000 C CNN
F 3 "" H 1450 2850 60  0000 C CNN
	1    1450 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 69C6E780
P 1600 2850
F 0 "U2" H 1600 3350 60  0000 C CNN
F 1 "plot_v1" H 1800 3200 60  0000 C CNN
F 2 "" H 1600 2850 60  0000 C CNN
F 3 "" H 1600 2850 60  0000 C CNN
	1    1600 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U12
U 1 1 69C6EC48
P 6250 2800
F 0 "U12" H 6250 3300 60  0000 C CNN
F 1 "plot_v1" H 6450 3150 60  0000 C CNN
F 2 "" H 6250 2800 60  0000 C CNN
F 3 "" H 6250 2800 60  0000 C CNN
	1    6250 2800
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U13
U 1 1 69C6ECB9
P 6550 2900
F 0 "U13" H 6550 3400 60  0000 C CNN
F 1 "plot_v1" H 6750 3250 60  0000 C CNN
F 2 "" H 6550 2900 60  0000 C CNN
F 3 "" H 6550 2900 60  0000 C CNN
	1    6550 2900
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U14
U 1 1 69C6ED1E
P 6950 3000
F 0 "U14" H 6950 3500 60  0000 C CNN
F 1 "plot_v1" H 7150 3350 60  0000 C CNN
F 2 "" H 6950 3000 60  0000 C CNN
F 3 "" H 6950 3000 60  0000 C CNN
	1    6950 3000
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U15
U 1 1 69C6ED85
P 7300 3050
F 0 "U15" H 7300 3550 60  0000 C CNN
F 1 "plot_v1" H 7500 3400 60  0000 C CNN
F 2 "" H 7300 3050 60  0000 C CNN
F 3 "" H 7300 3050 60  0000 C CNN
	1    7300 3050
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U16
U 1 1 69C6EDE0
P 7750 3100
F 0 "U16" H 7750 3600 60  0000 C CNN
F 1 "plot_v1" H 7950 3450 60  0000 C CNN
F 2 "" H 7750 3100 60  0000 C CNN
F 3 "" H 7750 3100 60  0000 C CNN
	1    7750 3100
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U17
U 1 1 69C6EE3F
P 8150 3200
F 0 "U17" H 8150 3700 60  0000 C CNN
F 1 "plot_v1" H 8350 3550 60  0000 C CNN
F 2 "" H 8150 3200 60  0000 C CNN
F 3 "" H 8150 3200 60  0000 C CNN
	1    8150 3200
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U18
U 1 1 69C6EEAA
P 8550 3250
F 0 "U18" H 8550 3750 60  0000 C CNN
F 1 "plot_v1" H 8750 3600 60  0000 C CNN
F 2 "" H 8550 3250 60  0000 C CNN
F 3 "" H 8550 3250 60  0000 C CNN
	1    8550 3250
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U19
U 1 1 69C6EF0B
P 8850 3400
F 0 "U19" H 8850 3900 60  0000 C CNN
F 1 "plot_v1" H 9050 3750 60  0000 C CNN
F 2 "" H 8850 3400 60  0000 C CNN
F 3 "" H 8850 3400 60  0000 C CNN
	1    8850 3400
	1    0    0    -1  
$EndComp
Text GLabel 6000 2600 0    60   Output ~ 0
y7
Text GLabel 6650 2800 2    60   Output ~ 0
y6
Text GLabel 7050 2950 2    60   Output ~ 0
y5
Text GLabel 7500 3000 2    60   Output ~ 0
y4
Text GLabel 7900 3050 2    60   Output ~ 0
y3
Text GLabel 8250 3150 2    60   Output ~ 0
y2
Text GLabel 8650 3200 2    60   Output ~ 0
y1
Text GLabel 9050 3300 2    60   Output ~ 0
y0
Text GLabel 1150 2150 0    60   Input ~ 0
clk0
Text GLabel 1600 2150 0    60   Input ~ 0
rst0
Text GLabel 1850 2000 0    60   Input ~ 0
sleep0
Text GLabel 2100 1950 0    60   Input ~ 0
d7
Text GLabel 2250 2100 0    60   Input ~ 0
d6
Text GLabel 2400 1950 0    60   Input ~ 0
d5
Text GLabel 2750 2050 0    60   Input ~ 0
d4
Text GLabel 3100 2050 0    60   Input ~ 0
d3
Text GLabel 3450 2100 0    60   Input ~ 0
d2
Text GLabel 3700 2100 0    60   Input ~ 0
d1
Text GLabel 4000 2150 0    60   Input ~ 0
d0
Wire Wire Line
	3500 3650 3800 3650
Wire Wire Line
	3800 3650 3800 3750
Wire Wire Line
	3800 3750 4150 3750
Wire Wire Line
	3300 3550 4000 3550
Wire Wire Line
	4000 3550 4000 3650
Wire Wire Line
	4000 3650 4150 3650
Wire Wire Line
	3150 3450 4050 3450
Wire Wire Line
	4050 3450 4050 3550
Wire Wire Line
	4050 3550 4150 3550
Wire Wire Line
	3000 3400 4150 3400
Wire Wire Line
	4150 3400 4150 3450
Wire Wire Line
	2850 3350 4150 3350
Wire Wire Line
	2650 3250 4150 3250
Wire Wire Line
	2450 3200 4150 3200
Wire Wire Line
	4150 3200 4150 3150
Wire Wire Line
	1700 2900 1700 3050
Wire Wire Line
	1700 2900 4150 2900
Wire Wire Line
	4150 2900 4150 2850
Wire Wire Line
	1500 2950 1500 2750
Wire Wire Line
	1450 2750 4150 2750
Wire Wire Line
	2150 3100 4150 3100
Wire Wire Line
	4150 3100 4150 3050
Wire Wire Line
	1900 3000 4150 3000
Wire Wire Line
	4150 3000 4150 2950
Wire Wire Line
	4000 2650 4000 3500
Wire Wire Line
	4000 3500 3850 3500
Wire Wire Line
	3850 3500 3850 3750
Connection ~ 3850 3750
Wire Wire Line
	3800 2650 3800 3550
Connection ~ 3800 3550
Wire Wire Line
	3550 2650 3550 3450
Connection ~ 3550 3450
Connection ~ 3250 3450
Wire Wire Line
	3000 2650 3100 2650
Wire Wire Line
	3100 2050 3100 3400
Connection ~ 3100 3400
Wire Wire Line
	2750 2650 2950 2650
Wire Wire Line
	2950 2650 2950 3350
Connection ~ 2950 3350
Wire Wire Line
	2500 2650 2500 2700
Wire Wire Line
	2500 2700 2800 2700
Wire Wire Line
	2800 2700 2800 3250
Connection ~ 2800 3250
Wire Wire Line
	2250 2650 2600 2650
Wire Wire Line
	2600 2650 2600 3200
Connection ~ 2600 3200
Wire Wire Line
	2000 2650 2200 2650
Wire Wire Line
	2200 2650 2200 2700
Wire Wire Line
	2200 2700 2350 2700
Wire Wire Line
	2350 2700 2350 3100
Connection ~ 2350 3100
Wire Wire Line
	1800 2650 1900 2650
Wire Wire Line
	1900 2650 1900 2700
Wire Wire Line
	1900 2700 2100 2700
Wire Wire Line
	2100 2700 2100 3000
Connection ~ 2100 3000
Wire Wire Line
	1600 2650 1750 2650
Wire Wire Line
	1750 2650 1750 2700
Wire Wire Line
	1750 2700 1850 2700
Wire Wire Line
	1850 2700 1850 2900
Connection ~ 1850 2900
Wire Wire Line
	1450 2650 1450 2750
Connection ~ 1500 2750
Wire Wire Line
	6250 2800 5800 2800
Wire Wire Line
	6250 2600 6250 2800
Wire Wire Line
	6250 2600 6000 2600
Wire Wire Line
	6550 2700 6550 2900
Wire Wire Line
	6550 2800 6650 2800
Wire Wire Line
	6550 2900 5800 2900
Connection ~ 6550 2800
Wire Wire Line
	6950 2800 6950 3000
Wire Wire Line
	6950 2950 7050 2950
Wire Wire Line
	6950 3000 5800 3000
Connection ~ 6950 2950
Wire Wire Line
	7300 2850 7300 3100
Wire Wire Line
	7300 3000 7500 3000
Wire Wire Line
	7300 3100 5800 3100
Connection ~ 7300 3000
Wire Wire Line
	7750 2900 7750 3200
Wire Wire Line
	7750 3050 7900 3050
Wire Wire Line
	7750 3200 5800 3200
Connection ~ 7750 3050
Wire Wire Line
	8150 3000 8150 3300
Wire Wire Line
	8150 3150 8250 3150
Wire Wire Line
	8150 3300 5800 3300
Connection ~ 8150 3150
Wire Wire Line
	5800 3400 8550 3400
Wire Wire Line
	8550 3400 8550 3050
Wire Wire Line
	8550 3200 8650 3200
Connection ~ 8550 3200
Wire Wire Line
	5800 3500 8850 3500
Wire Wire Line
	8850 3500 8850 3200
Wire Wire Line
	8850 3300 9050 3300
Connection ~ 8850 3300
Wire Wire Line
	4000 2150 4250 2150
Wire Wire Line
	4250 2150 4250 2650
Wire Wire Line
	4250 2650 4000 2650
Wire Wire Line
	3700 2100 3700 2600
Wire Wire Line
	3700 2600 3750 2600
Wire Wire Line
	3750 2600 3750 2700
Wire Wire Line
	3750 2700 3800 2700
Connection ~ 3800 2700
Wire Wire Line
	3450 2100 3450 2700
Wire Wire Line
	3450 2700 3550 2700
Connection ~ 3550 2700
Connection ~ 3100 2650
Wire Wire Line
	2750 2050 2750 2150
Wire Wire Line
	2750 2150 2850 2150
Wire Wire Line
	2850 2150 2850 2650
Connection ~ 2850 2650
Wire Wire Line
	2400 1950 2700 1950
Wire Wire Line
	2700 1950 2700 2700
Connection ~ 2700 2700
Wire Wire Line
	2250 2100 2400 2100
Wire Wire Line
	2400 2100 2400 2650
Connection ~ 2400 2650
Wire Wire Line
	2100 1950 2100 2650
Connection ~ 2100 2650
Wire Wire Line
	1850 2000 1850 2650
Connection ~ 1850 2650
Wire Wire Line
	1600 2150 1700 2150
Wire Wire Line
	1700 2150 1700 2650
Connection ~ 1700 2650
Wire Wire Line
	1150 2150 1150 2700
Wire Wire Line
	1150 2700 1450 2700
Connection ~ 1450 2700
$Comp
L pulse v3
U 1 1 69C7155F
P 1900 3450
F 0 "v3" H 1700 3550 60  0000 C CNN
F 1 "pulse" H 1700 3400 60  0000 C CNN
F 2 "R1" H 1600 3450 60  0000 C CNN
F 3 "" H 1900 3450 60  0000 C CNN
	1    1900 3450
	1    0    0    -1  
$EndComp
$Comp
L pulse v4
U 1 1 69C7188A
P 2150 3550
F 0 "v4" H 1950 3650 60  0000 C CNN
F 1 "pulse" H 1950 3500 60  0000 C CNN
F 2 "R1" H 1850 3550 60  0000 C CNN
F 3 "" H 2150 3550 60  0000 C CNN
	1    2150 3550
	1    0    0    -1  
$EndComp
$Comp
L pulse v5
U 1 1 69C718ED
P 2450 3650
F 0 "v5" H 2250 3750 60  0000 C CNN
F 1 "pulse" H 2250 3600 60  0000 C CNN
F 2 "R1" H 2150 3650 60  0000 C CNN
F 3 "" H 2450 3650 60  0000 C CNN
	1    2450 3650
	1    0    0    -1  
$EndComp
$Comp
L pulse v6
U 1 1 69C719B2
P 2650 3700
F 0 "v6" H 2450 3800 60  0000 C CNN
F 1 "pulse" H 2450 3650 60  0000 C CNN
F 2 "R1" H 2350 3700 60  0000 C CNN
F 3 "" H 2650 3700 60  0000 C CNN
	1    2650 3700
	1    0    0    -1  
$EndComp
$Comp
L pulse v7
U 1 1 69C71A01
P 2850 3800
F 0 "v7" H 2650 3900 60  0000 C CNN
F 1 "pulse" H 2650 3750 60  0000 C CNN
F 2 "R1" H 2550 3800 60  0000 C CNN
F 3 "" H 2850 3800 60  0000 C CNN
	1    2850 3800
	1    0    0    -1  
$EndComp
$Comp
L pulse v8
U 1 1 69C71AD0
P 3000 3850
F 0 "v8" H 2800 3950 60  0000 C CNN
F 1 "pulse" H 2800 3800 60  0000 C CNN
F 2 "R1" H 2700 3850 60  0000 C CNN
F 3 "" H 3000 3850 60  0000 C CNN
	1    3000 3850
	1    0    0    -1  
$EndComp
$Comp
L pulse v9
U 1 1 69C71B1F
P 3150 3900
F 0 "v9" H 2950 4000 60  0000 C CNN
F 1 "pulse" H 2950 3850 60  0000 C CNN
F 2 "R1" H 2850 3900 60  0000 C CNN
F 3 "" H 3150 3900 60  0000 C CNN
	1    3150 3900
	1    0    0    -1  
$EndComp
$Comp
L pulse v10
U 1 1 69C71B74
P 3300 4000
F 0 "v10" H 3100 4100 60  0000 C CNN
F 1 "pulse" H 3100 3950 60  0000 C CNN
F 2 "R1" H 3000 4000 60  0000 C CNN
F 3 "" H 3300 4000 60  0000 C CNN
	1    3300 4000
	1    0    0    -1  
$EndComp
$Comp
L pulse v11
U 1 1 69C71BD3
P 3500 4100
F 0 "v11" H 3300 4200 60  0000 C CNN
F 1 "pulse" H 3300 4050 60  0000 C CNN
F 2 "R1" H 3200 4100 60  0000 C CNN
F 3 "" H 3500 4100 60  0000 C CNN
	1    3500 4100
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR04
U 1 1 69C71C81
P 3500 4550
F 0 "#PWR04" H 3500 4300 50  0001 C CNN
F 1 "GND" H 3500 4400 50  0000 C CNN
F 2 "" H 3500 4550 50  0001 C CNN
F 3 "" H 3500 4550 50  0001 C CNN
	1    3500 4550
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR05
U 1 1 69C71CD3
P 3300 4450
F 0 "#PWR05" H 3300 4200 50  0001 C CNN
F 1 "GND" H 3300 4300 50  0000 C CNN
F 2 "" H 3300 4450 50  0001 C CNN
F 3 "" H 3300 4450 50  0001 C CNN
	1    3300 4450
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR06
U 1 1 69C71D25
P 3150 4350
F 0 "#PWR06" H 3150 4100 50  0001 C CNN
F 1 "GND" H 3150 4200 50  0000 C CNN
F 2 "" H 3150 4350 50  0001 C CNN
F 3 "" H 3150 4350 50  0001 C CNN
	1    3150 4350
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR07
U 1 1 69C71D77
P 3000 4300
F 0 "#PWR07" H 3000 4050 50  0001 C CNN
F 1 "GND" H 3000 4150 50  0000 C CNN
F 2 "" H 3000 4300 50  0001 C CNN
F 3 "" H 3000 4300 50  0001 C CNN
	1    3000 4300
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR08
U 1 1 69C71DC9
P 2850 4250
F 0 "#PWR08" H 2850 4000 50  0001 C CNN
F 1 "GND" H 2850 4100 50  0000 C CNN
F 2 "" H 2850 4250 50  0001 C CNN
F 3 "" H 2850 4250 50  0001 C CNN
	1    2850 4250
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR09
U 1 1 69C71E1B
P 2650 4150
F 0 "#PWR09" H 2650 3900 50  0001 C CNN
F 1 "GND" H 2650 4000 50  0000 C CNN
F 2 "" H 2650 4150 50  0001 C CNN
F 3 "" H 2650 4150 50  0001 C CNN
	1    2650 4150
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR010
U 1 1 69C71E6D
P 2450 4100
F 0 "#PWR010" H 2450 3850 50  0001 C CNN
F 1 "GND" H 2450 3950 50  0000 C CNN
F 2 "" H 2450 4100 50  0001 C CNN
F 3 "" H 2450 4100 50  0001 C CNN
	1    2450 4100
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR011
U 1 1 69C71EBF
P 2150 4000
F 0 "#PWR011" H 2150 3750 50  0001 C CNN
F 1 "GND" H 2150 3850 50  0000 C CNN
F 2 "" H 2150 4000 50  0001 C CNN
F 3 "" H 2150 4000 50  0001 C CNN
	1    2150 4000
	1    0    0    -1  
$EndComp
$EndSCHEMATC
