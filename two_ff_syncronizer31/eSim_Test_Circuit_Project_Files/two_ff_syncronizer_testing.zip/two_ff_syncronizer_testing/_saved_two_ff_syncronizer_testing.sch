EESchema Schematic File Version 2
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:power
LIBS:eSim_Plot
LIBS:transistors
LIBS:conn
LIBS:eSim_User
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_Nghdl
LIBS:eSim_Ngveri
LIBS:eSim_SKY130
LIBS:eSim_SKY130_Subckts
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L two_ff_syncronizer_ip X1
U 1 1 6A0B4E91
P 5300 3700
F 0 "X1" H 5300 3700 60  0000 C CNN
F 1 "two_ff_syncronizer_ip" H 5300 3600 60  0000 C CNN
F 2 "" H 5300 3700 60  0001 C CNN
F 3 "" H 5300 3700 60  0001 C CNN
	1    5300 3700
	1    0    0    -1  
$EndComp
$Comp
L pulse v1
U 1 1 6A0B4ED1
P 2750 3800
F 0 "v1" H 2550 3900 60  0000 C CNN
F 1 "pulse" H 2550 3750 60  0000 C CNN
F 2 "R1" H 2450 3800 60  0000 C CNN
F 3 "" H 2750 3800 60  0000 C CNN
	1    2750 3800
	1    0    0    -1  
$EndComp
$Comp
L pulse v2
U 1 1 6A0B4F3E
P 3350 3950
F 0 "v2" H 3150 4050 60  0000 C CNN
F 1 "pulse" H 3150 3900 60  0000 C CNN
F 2 "R1" H 3050 3950 60  0000 C CNN
F 3 "" H 3350 3950 60  0000 C CNN
	1    3350 3950
	1    0    0    -1  
$EndComp
$Comp
L pulse v3
U 1 1 6A0B4F6D
P 4050 4150
F 0 "v3" H 3850 4250 60  0000 C CNN
F 1 "pulse" H 3850 4100 60  0000 C CNN
F 2 "R1" H 3750 4150 60  0000 C CNN
F 3 "" H 4050 4150 60  0000 C CNN
	1    4050 4150
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U1
U 1 1 6A0B4FAE
P 2850 3100
F 0 "U1" H 2850 3600 60  0000 C CNN
F 1 "plot_v1" H 3050 3450 60  0000 C CNN
F 2 "" H 2850 3100 60  0000 C CNN
F 3 "" H 2850 3100 60  0000 C CNN
	1    2850 3100
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 6A0B5015
P 3600 3150
F 0 "U2" H 3600 3650 60  0000 C CNN
F 1 "plot_v1" H 3800 3500 60  0000 C CNN
F 2 "" H 3600 3150 60  0000 C CNN
F 3 "" H 3600 3150 60  0000 C CNN
	1    3600 3150
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U3
U 1 1 6A0B5054
P 3950 3200
F 0 "U3" H 3950 3700 60  0000 C CNN
F 1 "plot_v1" H 4150 3550 60  0000 C CNN
F 2 "" H 3950 3200 60  0000 C CNN
F 3 "" H 3950 3200 60  0000 C CNN
	1    3950 3200
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U4
U 1 1 6A0B507D
P 6350 3300
F 0 "U4" H 6350 3800 60  0000 C CNN
F 1 "plot_v1" H 6550 3650 60  0000 C CNN
F 2 "" H 6350 3300 60  0000 C CNN
F 3 "" H 6350 3300 60  0000 C CNN
	1    6350 3300
	1    0    0    -1  
$EndComp
Text GLabel 2250 2950 0    60   Input ~ 0
clk0
Text GLabel 3200 2900 0    60   Input ~ 0
rst_n0
Text GLabel 3800 2350 0    60   Input ~ 0
async_in0
Text GLabel 6800 3400 2    60   Output ~ 0
sync_out0
Wire Wire Line
	6350 3100 6350 3450
Wire Wire Line
	6350 3450 6000 3450
Wire Wire Line
	6800 3400 6350 3400
Connection ~ 6350 3400
Wire Wire Line
	4050 3700 4500 3700
Wire Wire Line
	4500 3700 4500 3750
Wire Wire Line
	3600 3550 4500 3550
Wire Wire Line
	3600 2950 3600 3550
Wire Wire Line
	3600 3500 3350 3500
Wire Wire Line
	4500 3400 2800 3400
Wire Wire Line
	2800 3400 2800 3350
Wire Wire Line
	2800 3350 2750 3350
Wire Wire Line
	2850 2900 2850 3400
Connection ~ 2850 3400
Wire Wire Line
	2250 2950 2850 2950
Connection ~ 2850 2950
Connection ~ 3600 3500
Wire Wire Line
	3200 2900 3500 2900
Wire Wire Line
	3500 2900 3500 3100
Wire Wire Line
	3500 3100 3600 3100
Connection ~ 3600 3100
Wire Wire Line
	3950 3000 3950 3200
Wire Wire Line
	3950 3200 4200 3200
Wire Wire Line
	4200 3200 4200 3700
Connection ~ 4200 3700
Wire Wire Line
	3800 2350 3800 3100
Wire Wire Line
	3800 3100 3950 3100
Connection ~ 3950 3100
$Comp
L GND #PWR01
U 1 1 6A0B5363
P 4050 4600
F 0 "#PWR01" H 4050 4350 50  0001 C CNN
F 1 "GND" H 4050 4450 50  0000 C CNN
F 2 "" H 4050 4600 50  0001 C CNN
F 3 "" H 4050 4600 50  0001 C CNN
	1    4050 4600
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR02
U 1 1 6A0B539F
P 3350 4400
F 0 "#PWR02" H 3350 4150 50  0001 C CNN
F 1 "GND" H 3350 4250 50  0000 C CNN
F 2 "" H 3350 4400 50  0001 C CNN
F 3 "" H 3350 4400 50  0001 C CNN
	1    3350 4400
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR03
U 1 1 6A0B53C3
P 2750 4250
F 0 "#PWR03" H 2750 4000 50  0001 C CNN
F 1 "GND" H 2750 4100 50  0000 C CNN
F 2 "" H 2750 4250 50  0001 C CNN
F 3 "" H 2750 4250 50  0001 C CNN
	1    2750 4250
	1    0    0    -1  
$EndComp
$EndSCHEMATC
