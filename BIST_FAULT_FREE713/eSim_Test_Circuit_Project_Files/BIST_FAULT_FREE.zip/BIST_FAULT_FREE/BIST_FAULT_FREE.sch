EESchema Schematic File Version 2
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:power
LIBS:eSim_Plot
LIBS:transistors
LIBS:conn
LIBS:eSim_User
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_Nghdl
LIBS:eSim_Ngveri
LIBS:eSim_SKY130
LIBS:eSim_SKY130_Subckts
LIBS:BIST_FAULT_FREE-cache
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L pulse v1
U 1 1 69BE37A8
P 900 3300
F 0 "v1" H 700 3400 60  0000 C CNN
F 1 "pulse" H 700 3250 60  0000 C CNN
F 2 "R1" H 600 3300 60  0000 C CNN
F 3 "" H 900 3300 60  0000 C CNN
	1    900  3300
	1    0    0    -1  
$EndComp
$Comp
L pulse v2
U 1 1 69BE3839
P 1350 3400
F 0 "v2" H 1150 3500 60  0000 C CNN
F 1 "pulse" H 1150 3350 60  0000 C CNN
F 2 "R1" H 1050 3400 60  0000 C CNN
F 3 "" H 1350 3400 60  0000 C CNN
	1    1350 3400
	1    0    0    -1  
$EndComp
$Comp
L pulse v3
U 1 1 69BE39ED
P 1650 3500
F 0 "v3" H 1450 3600 60  0000 C CNN
F 1 "pulse" H 1450 3450 60  0000 C CNN
F 2 "R1" H 1350 3500 60  0000 C CNN
F 3 "" H 1650 3500 60  0000 C CNN
	1    1650 3500
	1    0    0    -1  
$EndComp
$Comp
L DC v4
U 1 1 69BE3A18
P 2000 3600
F 0 "v4" H 1800 3700 60  0000 C CNN
F 1 "DC" H 1800 3550 60  0000 C CNN
F 2 "R1" H 1700 3600 60  0000 C CNN
F 3 "" H 2000 3600 60  0000 C CNN
	1    2000 3600
	1    0    0    -1  
$EndComp
$Comp
L DC v5
U 1 1 69BE3A43
P 2350 3700
F 0 "v5" H 2150 3800 60  0000 C CNN
F 1 "DC" H 2150 3650 60  0000 C CNN
F 2 "R1" H 2050 3700 60  0000 C CNN
F 3 "" H 2350 3700 60  0000 C CNN
	1    2350 3700
	1    0    0    -1  
$EndComp
$Comp
L DC v6
U 1 1 69BE3A74
P 2950 4000
F 0 "v6" H 2750 4100 60  0000 C CNN
F 1 "DC" H 2750 3950 60  0000 C CNN
F 2 "R1" H 2650 4000 60  0000 C CNN
F 3 "" H 2950 4000 60  0000 C CNN
	1    2950 4000
	1    0    0    -1  
$EndComp
$Comp
L DC v7
U 1 1 69BE3AA5
P 3400 4100
F 0 "v7" H 3200 4200 60  0000 C CNN
F 1 "DC" H 3200 4050 60  0000 C CNN
F 2 "R1" H 3100 4100 60  0000 C CNN
F 3 "" H 3400 4100 60  0000 C CNN
	1    3400 4100
	1    0    0    -1  
$EndComp
$Comp
L eSim_GND #PWR01
U 1 1 69BE3D64
P 4350 1550
F 0 "#PWR01" H 4350 1300 50  0001 C CNN
F 1 "eSim_GND" H 4350 1400 50  0000 C CNN
F 2 "" H 4350 1550 50  0001 C CNN
F 3 "" H 4350 1550 50  0001 C CNN
	1    4350 1550
	0    1    1    0   
$EndComp
$Comp
L DC v8
U 1 1 69BE3D88
P 4950 1550
F 0 "v8" H 4750 1650 60  0000 C CNN
F 1 "DC" H 4750 1500 60  0000 C CNN
F 2 "R1" H 4650 1550 60  0000 C CNN
F 3 "" H 4950 1550 60  0000 C CNN
	1    4950 1550
	0    1    1    0   
$EndComp
$Comp
L eSim_VCC #PWR02
U 1 1 69BE3DCD
P 5750 1550
F 0 "#PWR02" H 5750 1400 50  0001 C CNN
F 1 "eSim_VCC" H 5750 1700 50  0000 C CNN
F 2 "" H 5750 1550 50  0001 C CNN
F 3 "" H 5750 1550 50  0001 C CNN
	1    5750 1550
	0    1    1    0   
$EndComp
$Comp
L eSim_GND #PWR03
U 1 1 69BE3DF3
P 850 3900
F 0 "#PWR03" H 850 3650 50  0001 C CNN
F 1 "eSim_GND" H 850 3750 50  0000 C CNN
F 2 "" H 850 3900 50  0001 C CNN
F 3 "" H 850 3900 50  0001 C CNN
	1    850  3900
	1    0    0    -1  
$EndComp
$Comp
L eSim_GND #PWR04
U 1 1 69BE3E19
P 1350 4050
F 0 "#PWR04" H 1350 3800 50  0001 C CNN
F 1 "eSim_GND" H 1350 3900 50  0000 C CNN
F 2 "" H 1350 4050 50  0001 C CNN
F 3 "" H 1350 4050 50  0001 C CNN
	1    1350 4050
	1    0    0    -1  
$EndComp
$Comp
L eSim_GND #PWR05
U 1 1 69BE3E3F
P 1650 4200
F 0 "#PWR05" H 1650 3950 50  0001 C CNN
F 1 "eSim_GND" H 1650 4050 50  0000 C CNN
F 2 "" H 1650 4200 50  0001 C CNN
F 3 "" H 1650 4200 50  0001 C CNN
	1    1650 4200
	1    0    0    -1  
$EndComp
$Comp
L eSim_GND #PWR06
U 1 1 69BE3E65
P 2000 4250
F 0 "#PWR06" H 2000 4000 50  0001 C CNN
F 1 "eSim_GND" H 2000 4100 50  0000 C CNN
F 2 "" H 2000 4250 50  0001 C CNN
F 3 "" H 2000 4250 50  0001 C CNN
	1    2000 4250
	1    0    0    -1  
$EndComp
$Comp
L eSim_GND #PWR07
U 1 1 69BE3E8B
P 2400 4400
F 0 "#PWR07" H 2400 4150 50  0001 C CNN
F 1 "eSim_GND" H 2400 4250 50  0000 C CNN
F 2 "" H 2400 4400 50  0001 C CNN
F 3 "" H 2400 4400 50  0001 C CNN
	1    2400 4400
	1    0    0    -1  
$EndComp
$Comp
L eSim_GND #PWR08
U 1 1 69BE3EF0
P 2950 4600
F 0 "#PWR08" H 2950 4350 50  0001 C CNN
F 1 "eSim_GND" H 2950 4450 50  0000 C CNN
F 2 "" H 2950 4600 50  0001 C CNN
F 3 "" H 2950 4600 50  0001 C CNN
	1    2950 4600
	1    0    0    -1  
$EndComp
$Comp
L eSim_GND #PWR09
U 1 1 69BE3F16
P 3400 4750
F 0 "#PWR09" H 3400 4500 50  0001 C CNN
F 1 "eSim_GND" H 3400 4600 50  0000 C CNN
F 2 "" H 3400 4750 50  0001 C CNN
F 3 "" H 3400 4750 50  0001 C CNN
	1    3400 4750
	1    0    0    -1  
$EndComp
Text GLabel 650  2700 0    60   Input ~ 0
clk0
Text GLabel 1400 2650 0    60   Input ~ 0
rst0
Text GLabel 2250 2600 0    60   Input ~ 0
testmode0
Text GLabel 2700 2600 0    60   Input ~ 0
in3
Text GLabel 3100 2600 0    60   Input ~ 0
in2
Text GLabel 3500 2650 0    60   Input ~ 0
in1
Text GLabel 3950 2700 0    60   Input ~ 0
in0
$Comp
L plot_v1 U1
U 1 1 69BE40EA
P 800 2850
F 0 "U1" H 800 3350 60  0000 C CNN
F 1 "plot_v1" H 1000 3200 60  0000 C CNN
F 2 "" H 800 2850 60  0000 C CNN
F 3 "" H 800 2850 60  0000 C CNN
	1    800  2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 69BE4159
P 1500 2700
F 0 "U2" H 1500 3200 60  0000 C CNN
F 1 "plot_v1" H 1700 3050 60  0000 C CNN
F 2 "" H 1500 2700 60  0000 C CNN
F 3 "" H 1500 2700 60  0000 C CNN
	1    1500 2700
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U4
U 1 1 69BE4198
P 2400 2750
F 0 "U4" H 2400 3250 60  0000 C CNN
F 1 "plot_v1" H 2600 3100 60  0000 C CNN
F 2 "" H 2400 2750 60  0000 C CNN
F 3 "" H 2400 2750 60  0000 C CNN
	1    2400 2750
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U5
U 1 1 69BE41E3
P 2800 2700
F 0 "U5" H 2800 3200 60  0000 C CNN
F 1 "plot_v1" H 3000 3050 60  0000 C CNN
F 2 "" H 2800 2700 60  0000 C CNN
F 3 "" H 2800 2700 60  0000 C CNN
	1    2800 2700
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U6
U 1 1 69BE4224
P 3200 2750
F 0 "U6" H 3200 3250 60  0000 C CNN
F 1 "plot_v1" H 3400 3100 60  0000 C CNN
F 2 "" H 3200 2750 60  0000 C CNN
F 3 "" H 3200 2750 60  0000 C CNN
	1    3200 2750
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U7
U 1 1 69BE426F
P 3650 2800
F 0 "U7" H 3650 3300 60  0000 C CNN
F 1 "plot_v1" H 3850 3150 60  0000 C CNN
F 2 "" H 3650 2800 60  0000 C CNN
F 3 "" H 3650 2800 60  0000 C CNN
	1    3650 2800
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U8
U 1 1 69BE42BC
P 4100 2850
F 0 "U8" H 4100 3350 60  0000 C CNN
F 1 "plot_v1" H 4300 3200 60  0000 C CNN
F 2 "" H 4100 2850 60  0000 C CNN
F 3 "" H 4100 2850 60  0000 C CNN
	1    4100 2850
	1    0    0    -1  
$EndComp
Text GLabel 8250 2350 2    60   Output ~ 0
out3
Text GLabel 8800 2550 2    60   Output ~ 0
out2
Text GLabel 9450 2750 2    60   Output ~ 0
out1
Text GLabel 9850 2950 2    60   Output ~ 0
out0
Text GLabel 10150 3200 2    60   Output ~ 0
fault_detected0
Text GLabel 10650 3450 2    60   Output ~ 0
misr_out3
Text GLabel 11250 3600 2    60   Output ~ 0
misr_out2
Text GLabel 11650 3800 2    60   Output ~ 0
misr_out1
Text GLabel 12000 4050 2    60   Output ~ 0
misr_out0
Text GLabel 9000 3900 2    60   Output ~ 0
complete3
Text GLabel 9600 4100 2    60   Output ~ 0
complete2
Text GLabel 10450 4300 2    60   Output ~ 0
complete1
Text GLabel 11250 4450 2    60   Output ~ 0
complete0
$Comp
L plot_v1 U9
U 1 1 69BE481D
P 8050 2450
F 0 "U9" H 8050 2950 60  0000 C CNN
F 1 "plot_v1" H 8250 2800 60  0000 C CNN
F 2 "" H 8050 2450 60  0000 C CNN
F 3 "" H 8050 2450 60  0000 C CNN
	1    8050 2450
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U10
U 1 1 69BE48AC
P 8650 2600
F 0 "U10" H 8650 3100 60  0000 C CNN
F 1 "plot_v1" H 8850 2950 60  0000 C CNN
F 2 "" H 8650 2600 60  0000 C CNN
F 3 "" H 8650 2600 60  0000 C CNN
	1    8650 2600
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U12
U 1 1 69BE4901
P 9400 2650
F 0 "U12" H 9400 3150 60  0000 C CNN
F 1 "plot_v1" H 9600 3000 60  0000 C CNN
F 2 "" H 9400 2650 60  0000 C CNN
F 3 "" H 9400 2650 60  0000 C CNN
	1    9400 2650
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U14
U 1 1 69BE494A
P 9800 2850
F 0 "U14" H 9800 3350 60  0000 C CNN
F 1 "plot_v1" H 10000 3200 60  0000 C CNN
F 2 "" H 9800 2850 60  0000 C CNN
F 3 "" H 9800 2850 60  0000 C CNN
	1    9800 2850
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U16
U 1 1 69BE4997
P 10200 3200
F 0 "U16" H 10200 3700 60  0000 C CNN
F 1 "plot_v1" H 10400 3550 60  0000 C CNN
F 2 "" H 10200 3200 60  0000 C CNN
F 3 "" H 10200 3200 60  0000 C CNN
	1    10200 3200
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U18
U 1 1 69BE4A06
P 11000 3350
F 0 "U18" H 11000 3850 60  0000 C CNN
F 1 "plot_v1" H 11200 3700 60  0000 C CNN
F 2 "" H 11000 3350 60  0000 C CNN
F 3 "" H 11000 3350 60  0000 C CNN
	1    11000 3350
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U19
U 1 1 69BE4A63
P 11400 3550
F 0 "U19" H 11400 4050 60  0000 C CNN
F 1 "plot_v1" H 11600 3900 60  0000 C CNN
F 2 "" H 11400 3550 60  0000 C CNN
F 3 "" H 11400 3550 60  0000 C CNN
	1    11400 3550
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U20
U 1 1 69BE4AB8
P 11900 3650
F 0 "U20" H 11900 4150 60  0000 C CNN
F 1 "plot_v1" H 12100 4000 60  0000 C CNN
F 2 "" H 11900 3650 60  0000 C CNN
F 3 "" H 11900 3650 60  0000 C CNN
	1    11900 3650
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U21
U 1 1 69BE4B11
P 12250 3950
F 0 "U21" H 12250 4450 60  0000 C CNN
F 1 "plot_v1" H 12450 4300 60  0000 C CNN
F 2 "" H 12250 3950 60  0000 C CNN
F 3 "" H 12250 3950 60  0000 C CNN
	1    12250 3950
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U11
U 1 1 69BE4B6A
P 8750 4200
F 0 "U11" H 8750 4700 60  0000 C CNN
F 1 "plot_v1" H 8950 4550 60  0000 C CNN
F 2 "" H 8750 4200 60  0000 C CNN
F 3 "" H 8750 4200 60  0000 C CNN
	1    8750 4200
	-1   0    0    1   
$EndComp
$Comp
L plot_v1 U13
U 1 1 69BE4C15
P 9400 4250
F 0 "U13" H 9400 4750 60  0000 C CNN
F 1 "plot_v1" H 9600 4600 60  0000 C CNN
F 2 "" H 9400 4250 60  0000 C CNN
F 3 "" H 9400 4250 60  0000 C CNN
	1    9400 4250
	-1   0    0    1   
$EndComp
$Comp
L plot_v1 U15
U 1 1 69BE4C8A
P 9950 4500
F 0 "U15" H 9950 5000 60  0000 C CNN
F 1 "plot_v1" H 10150 4850 60  0000 C CNN
F 2 "" H 9950 4500 60  0000 C CNN
F 3 "" H 9950 4500 60  0000 C CNN
	1    9950 4500
	-1   0    0    1   
$EndComp
$Comp
L plot_v1 U17
U 1 1 69BE4D09
P 10750 4650
F 0 "U17" H 10750 5150 60  0000 C CNN
F 1 "plot_v1" H 10950 5000 60  0000 C CNN
F 2 "" H 10750 4650 60  0000 C CNN
F 3 "" H 10750 4650 60  0000 C CNN
	1    10750 4650
	-1   0    0    1   
$EndComp
$Comp
L dac_bridge_8 U23
U 1 1 69BE93D1
P 7350 3050
F 0 "U23" H 7350 3050 60  0000 C CNN
F 1 "dac_bridge_8" H 7350 3200 60  0000 C CNN
F 2 "" H 7350 3050 60  0000 C CNN
F 3 "" H 7350 3050 60  0000 C CNN
	1    7350 3050
	1    0    0    -1  
$EndComp
$Comp
L dac_bridge_5 U24
U 1 1 69BE9434
P 7350 3850
F 0 "U24" H 7350 3850 60  0000 C CNN
F 1 "dac_bridge_5" H 7350 4000 60  0000 C CNN
F 2 "" H 7350 3850 60  0000 C CNN
F 3 "" H 7350 3850 60  0000 C CNN
	1    7350 3850
	1    0    0    -1  
$EndComp
$Comp
L adc_bridge_7 U22
U 1 1 69BE9D9B
P 4800 3050
F 0 "U22" H 4800 3050 60  0000 C CNN
F 1 "adc_bridge_7" H 4800 3200 60  0000 C CNN
F 2 "" H 4800 3050 60  0000 C CNN
F 3 "" H 4800 3050 60  0000 C CNN
	1    4800 3050
	1    0    0    -1  
$EndComp
Wire Wire Line
	3750 3000 4200 3000
Wire Wire Line
	3750 3000 3750 2850
Wire Wire Line
	3750 2850 900  2850
Wire Wire Line
	3550 3100 4200 3100
Wire Wire Line
	3550 3100 3550 2950
Wire Wire Line
	3550 2950 1350 2950
Wire Wire Line
	3350 3200 4200 3200
Wire Wire Line
	3350 3200 3350 3050
Wire Wire Line
	3350 3050 1650 3050
Wire Wire Line
	3200 3300 4200 3300
Wire Wire Line
	3200 3300 3200 3150
Wire Wire Line
	3200 3150 2000 3150
Wire Wire Line
	3050 3400 4200 3400
Wire Wire Line
	3050 3400 3050 3250
Wire Wire Line
	2350 3250 3100 3250
Wire Wire Line
	2950 3500 4200 3500
Wire Wire Line
	2950 3500 2950 3550
Wire Wire Line
	3400 3600 4200 3600
Wire Wire Line
	3400 3600 3400 3650
Wire Wire Line
	4350 1550 4500 1550
Wire Wire Line
	5400 1550 5750 1550
Wire Wire Line
	3400 4550 3400 4750
Wire Wire Line
	2950 4450 2950 4600
Wire Wire Line
	2350 4150 2350 4400
Wire Wire Line
	2350 4400 2400 4400
Wire Wire Line
	2000 4050 2000 4250
Wire Wire Line
	1650 3950 1650 4200
Wire Wire Line
	1350 3850 1350 4050
Wire Wire Line
	900  3750 900  3900
Wire Wire Line
	900  3900 850  3900
Wire Wire Line
	800  2650 1000 2650
Wire Wire Line
	1000 2650 1000 2850
Connection ~ 1000 2850
Wire Wire Line
	650  2700 1000 2700
Connection ~ 1000 2700
Wire Wire Line
	1400 2650 1400 2750
Wire Wire Line
	1400 2750 1550 2750
Wire Wire Line
	1550 2750 1550 2950
Connection ~ 1550 2950
Wire Wire Line
	1500 2500 1500 2750
Connection ~ 1500 2750
Wire Wire Line
	2250 2600 2250 3050
Connection ~ 2250 3050
Wire Wire Line
	2400 2550 2350 2550
Wire Wire Line
	2350 2550 2350 2750
Wire Wire Line
	2350 2750 2250 2750
Connection ~ 2250 2750
Wire Wire Line
	2700 2600 2700 3150
Connection ~ 2700 3150
Wire Wire Line
	2800 2500 2800 2700
Wire Wire Line
	2800 2700 2700 2700
Connection ~ 2700 2700
Wire Wire Line
	3100 3250 3100 2600
Connection ~ 3050 3250
Wire Wire Line
	3200 2550 3200 2750
Wire Wire Line
	3200 2750 3100 2750
Connection ~ 3100 2750
Wire Wire Line
	3500 2650 3500 3500
Connection ~ 3500 3500
Wire Wire Line
	3650 2600 3650 2750
Wire Wire Line
	3650 2750 3500 2750
Connection ~ 3500 2750
Wire Wire Line
	3950 2700 3950 3600
Connection ~ 3950 3600
Wire Wire Line
	4100 2650 4100 2800
Wire Wire Line
	4100 2800 3950 2800
Wire Wire Line
	3950 2800 3950 2850
Connection ~ 3950 2850
Wire Wire Line
	7900 3000 8150 3000
Wire Wire Line
	8150 3000 8150 2350
Wire Wire Line
	8050 2350 8250 2350
Wire Wire Line
	8050 2250 8050 2350
Connection ~ 8150 2350
Wire Wire Line
	8650 3100 7900 3100
Wire Wire Line
	8650 2400 8650 3100
Wire Wire Line
	8650 2550 8800 2550
Connection ~ 8650 2550
Wire Wire Line
	9400 2450 9400 3200
Wire Wire Line
	9400 2750 9450 2750
Wire Wire Line
	9400 3200 7900 3200
Connection ~ 9400 2750
Wire Wire Line
	9800 2650 9800 3300
Wire Wire Line
	9800 2950 9850 2950
Wire Wire Line
	9800 3300 7900 3300
Connection ~ 9800 2950
Wire Wire Line
	10200 3000 10200 3100
Wire Wire Line
	10200 3100 10050 3100
Wire Wire Line
	10050 3100 10050 3400
Wire Wire Line
	10050 3200 10150 3200
Wire Wire Line
	10050 3400 7900 3400
Connection ~ 10050 3200
Wire Wire Line
	11000 3150 10950 3150
Wire Wire Line
	10950 3150 10950 3350
Wire Wire Line
	10950 3350 10550 3350
Wire Wire Line
	10550 3350 10550 3500
Wire Wire Line
	10550 3450 10650 3450
Wire Wire Line
	10550 3500 7900 3500
Connection ~ 10550 3450
Wire Wire Line
	7900 3600 11250 3600
Wire Wire Line
	11200 3600 11200 3400
Wire Wire Line
	11200 3400 11400 3400
Wire Wire Line
	11400 3400 11400 3350
Connection ~ 11200 3600
Wire Wire Line
	11900 3700 11900 3450
Wire Wire Line
	7900 3700 11900 3700
Wire Wire Line
	11450 3700 11450 3800
Wire Wire Line
	11450 3800 11650 3800
Connection ~ 11450 3700
Wire Wire Line
	12250 3750 12250 3950
Wire Wire Line
	12250 3950 11900 3950
Wire Wire Line
	11900 3950 11900 4050
Wire Wire Line
	11900 4050 12000 4050
Wire Wire Line
	7900 3800 11300 3800
Wire Wire Line
	11300 3800 11300 4000
Wire Wire Line
	11300 4000 11900 4000
Connection ~ 11900 4000
Wire Wire Line
	7900 3900 9000 3900
Wire Wire Line
	8750 4400 8750 3900
Connection ~ 8750 3900
Wire Wire Line
	7900 4000 9400 4000
Wire Wire Line
	9400 4000 9400 4450
Wire Wire Line
	9400 4100 9600 4100
Connection ~ 9400 4100
Wire Wire Line
	7900 4100 9250 4100
Wire Wire Line
	9250 4100 9250 4300
Wire Wire Line
	9250 4300 10450 4300
Wire Wire Line
	9950 4700 9950 4300
Connection ~ 9950 4300
Wire Wire Line
	7900 4200 8150 4200
Wire Wire Line
	8150 4200 8150 4450
Wire Wire Line
	8150 4450 11250 4450
Wire Wire Line
	10750 4850 10750 4450
Connection ~ 10750 4450
$Comp
L bist_fault_free U3
U 1 1 69BE498F
P 3200 4900
F 0 "U3" H 6050 6700 60  0000 C CNN
F 1 "bist_fault_free" H 6050 6900 60  0000 C CNN
F 2 "" H 6050 6850 60  0000 C CNN
F 3 "" H 6050 6850 60  0000 C CNN
	1    3200 4900
	1    0    0    -1  
$EndComp
$EndSCHEMATC
